script.hyperion.switch
